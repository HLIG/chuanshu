function grad_x=cal_grad_x(image,window_size,diff_thres)
    [rows,cols]=size(image);
    grad_x=zeros(size(image));
    for row=1:rows
        max_index=1;
        max_value=image(row,1);
        min_index=1;
        min_value=image(row,1);
        %% ǰ��window_size��
        for col=1:window_size
            if image(row,col)>=image(row,max_index)
                max_index=col;
                max_value=image(row,col);
                if max_value-min_value>=diff_thres
                    grad_x(row,col)=max_value-min_value;
                    min_value=image(row,col);
                    min_index=col;
                end
            end
            if image(row,col)<=image(row,min_index)
                min_index=col;
                min_value=image(row,col);
                if max_value-min_value>=diff_thres
                    grad_x(row,col)=max_value-min_value;
                    max_value=image(row,col);
                    max_index=col;
                end
            end
        end
        
        %% �������
        for col=window_size+1:cols
            % �ȰѶ���ǰ���ֵ�޳�
            if min_index==col-window_size
                min_index=col-window_size+1;
                min_value=image(row,col-window_size+1);
                for col_i=col-window_size+1:col-1
                    if image(row,col_i)<=min_value
                        min_value=image(row,col_i);
                        min_index=col_i;
                    end
                end
            end
            if max_index==col-window_size
                max_index=col-window_size+1;
                max_value=image(row,col-window_size+1);
                for col_i=col-window_size+1:col-1
                    if image(row,col_i)>=max_value
                        max_value=image(row,col_i);
                        max_index=col_i;
                    end
                end
            end
            
            % �жϱ�Ե
            if image(row,col)>=image(row,max_index)
                max_index=col;
                max_value=image(row,col);
                if max_value-min_value>=diff_thres
                    grad_x(row,col)=max_value-min_value;
                    min_value=image(row,col);
                    min_index=col;
                end
            end
            if image(row,col)<=image(row,min_index)
                min_index=col;
                min_value=image(row,col);
                if max_value-min_value>=diff_thres
                    grad_x(row,col)=max_value-min_value;
                    max_value=image(row,col);
                    max_index=col;
                end
            end
                
            
        end
    end
        
end