close all
image=im2double(imread('lena.png'));
figure;imshow(image,[]);
noisy_image=imnoise(image, 'gaussian', 0, (40/255)^2);
% figure;imshow(noisy_image,[]);


%% gaussain filter
sigma=2;%��׼���С
window=double(uint8(3*sigma)*2+1);%���ڴ�Сһ��Ϊ3*sigma
H=fspecial('gaussian', window, sigma);%fspecial('gaussian', hsize, sigma)�����˲�ģ��
%Ϊ�˲����ֺڱߣ�ʹ�ò���'replicate'������ͼ����ⲿ�߽�ͨ�������ڲ��߽��ֵ����չ��
img_gauss=imfilter(noisy_image,H,'replicate');
% figure;imshow(img_gauss,[]);
figure;imshow(img_gauss(:,:,1),[]);title('R');
figure;imshow(img_gauss(:,:,2),[]);title('G');
figure;imshow(img_gauss(:,:,3),[]);title('B');

%% cal diff 
R_grad_x=abs(diff(img_gauss(:,:,1),1,2));
R_grad_y=abs(diff(img_gauss(:,:,1),1,1));
% figure;imshow(R_grad_x,[]);title('R-grad-x');
% figure;imshow(R_grad_y,[]);title('R-grad-y');

G_grad_x=abs(diff(img_gauss(:,:,2),1,2));
G_grad_y=abs(diff(img_gauss(:,:,2),1,1));
% figure;imshow(G_grad_x,[]);title('G-grad-x');
% figure;imshow(G_grad_y,[]);title('G-grad-y');

B_grad_x=abs(diff(img_gauss(:,:,3),1,2));
B_grad_x(B_grad_x<0.020)=0;
B_grad_y=abs(diff(img_gauss(:,:,3),1,1));

figure;imshow(B_grad_x,[]);title('B-grad-x');

% figure;imshow(B_grad_y,[]);title('B-grad-y');

%% cal grad_x
image=img_gauss(:,:,1);
window_size=5;
diff_thres=30/255.;
B_grad_x1=cal_grad_x(image,window_size,diff_thres);
figure;imshow(B_grad_x1,[]);title('B-grad-x3');

image1=image';
window_size=6;
diff_thres=40/255.;
B_grad_x1=cal_grad_x(image1,window_size,diff_thres);
figure;imshow(B_grad_x1',[]);title('B-grad-y3');

