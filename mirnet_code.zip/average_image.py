import cv2
import os
import glob
import  numpy as np
image_list1=sorted(glob.glob(r'E:\goodix\HLG\competition\Denoise\MIRNet-master\results\denoising\MAI\MIRNet_base1_ensemble\*.png'))
image_list2=sorted(glob.glob(r'E:\goodix\HLG\competition\Denoise\MIRNet-master\results\denoising\MAI\MIRNet_base2_ensemble\*.png'))
for image1_path,image2_path in zip(image_list1,image_list2):
    image1=cv2.imread(image1_path,cv2.IMREAD_UNCHANGED)
    image2=cv2.imread(image2_path,cv2.IMREAD_UNCHANGED)

    image=(np.float32(image1)+np.float32(image2))/2.
    image=np.uint8(np.round(np.clip(image,0,255)))
    cv2.imwrite(image1_path.replace('MIRNet_base1_ensemble','MIRNet_base1+base2_ensemble'),image)
    print(image1_path,image2_path)