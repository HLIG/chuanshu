

"""
## Learning Enriched Features for Real Image Restoration and Enhancement
## Syed Waqas Zamir, Aditya Arora, Salman Khan, Munawar Hayat, Fahad Shahbaz Khan, Ming-Hsuan Yang, and Ling Shao
## ECCV 2020
## https://arxiv.org/abs/2003.06792
"""
from Image_Self_Ensemble import self_image_ensemble
from Crop_Image import crop_image,merge_image
import numpy as np
import os
import argparse
from tqdm import tqdm
import cv2
import torch.nn as nn
import torch
from torch.utils.data import DataLoader
import torch.nn.functional as F

import scipy.io as sio
from networks.MIRNet_model import MIRNet
from networks.MPRNet1 import MPRNet
from dataloaders.data_rgb import get_validation_data,get_test_data
import utils
from skimage import img_as_ubyte

parser = argparse.ArgumentParser(description='RGB denoising evaluation on the validation set of SIDD')
parser.add_argument('--input_dir', default=r'E://goodix//HLG//competition//Denoise//MAI2021_denoising_test_cropped_nois//',
    type=str, help='Directory of validation images')
parser.add_argument('--result_dir', default='E:\goodix\HLG\competition\MAI\submit\\',
    type=str, help='Directory for results')
parser.add_argument('--weights', default='E:\goodix\HLG\competition\Denoise\MIRNet-master\checkpoints\Denoising\models\MPRNet-pixelshuffle\\model_epoch_281.pth',
    type=str, help='Path to weights')
parser.add_argument('--gpus', default='0', type=str, help='CUDA_VISIBLE_DEVICES')
parser.add_argument('--bs', default=1, type=int, help='Batch size for dataloader')
parser.add_argument('--save_images', action='store_true', help='Save denoised images in result directory')

args = parser.parse_args()


os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = args.gpus

utils.mkdir(args.result_dir)

test_dataset = get_test_data(args.input_dir)
test_loader = DataLoader(dataset=test_dataset, batch_size=args.bs, shuffle=False, num_workers=0, drop_last=False)



model_restoration = MPRNet()
print(model_restoration.parameters())
utils.load_checkpoint(model_restoration,args.weights)
print("===>Testing using weights: ", args.weights)

model_restoration.cuda()

model_restoration=nn.DataParallel(model_restoration)

model_restoration.eval()

crop_row=640
crop_col=640
padding_size=32
self_ensemble_flag=False
self_ensemble_num=1
if self_ensemble_flag:
    self_ensemble_num=8

with torch.no_grad():
    psnr_val_rgb = []
    for ii, data_test in enumerate(tqdm(test_loader), 0):
        rgb_noisy_src = data_test[0][0]
        filename = data_test[1]
        select_row_id, select_col_id, crop_results = crop_image(rgb_noisy_src.numpy(), crop_row, crop_col, padding_size)
        crops_denoised1=[]
        crops_denoised2 = []
        crops_denoised3 = []
        for image_i,rgb_noisy in enumerate(crop_results):
            final_denoise_img1=0.
            final_denoise_img2=0.
            final_denoise_img3=0.
            for sele_ensemble_i in range(self_ensemble_num):
                rgb_noisy_input=self_image_ensemble(np.uint8(rgb_noisy),sele_ensemble_i,inverse_flag=False)
                rgb_noisy_input = torch.from_numpy(np.float32(rgb_noisy_input)/255.).permute(2, 0, 1)
                rgb_noisy_input=rgb_noisy_input[np.newaxis,:]
                rgb_noisy_input=rgb_noisy_input.cuda()
                rgb_restored = model_restoration(rgb_noisy_input)
                rgb_restored1=rgb_restored
                # rgb_restored1=rgb_restored[0]
                # rgb_restored2=rgb_restored[1]
                # rgb_restored3=rgb_restored[2]
                rgb_restored1 = torch.clamp(rgb_restored1,0,1)
                # rgb_restored2 = torch.clamp(rgb_restored2,0,1)
                # rgb_restored3 = torch.clamp(rgb_restored3,0,1)

                # psnr_val_rgb.append(utils.batch_PSNR(rgb_restored, rgb_gt, 1.))

                # rgb_gt = rgb_gt.permute(0, 2, 3, 1).cpu().detach().numpy()
                # rgb_noisy = rgb_noisy.permute(0, 2, 3, 1).cpu().detach().numpy()
                rgb_restored1= rgb_restored1.permute(0, 2, 3, 1).cpu().detach().numpy()
                # rgb_restored2= rgb_restored2.permute(0, 2, 3, 1).cpu().detach().numpy()
                # rgb_restored3= rgb_restored3.permute(0, 2, 3, 1).cpu().detach().numpy()
                denoised_img1 = img_as_ubyte(rgb_restored1[0])
                # denoised_img2 = img_as_ubyte(rgb_restored2[0])
                # denoised_img3 = img_as_ubyte(rgb_restored3[0])

                denoised_img1=self_image_ensemble(denoised_img1,sele_ensemble_i,inverse_flag=True)
                # denoised_img2=self_image_ensemble(denoised_img2,sele_ensemble_i,inverse_flag=True)
                # denoised_img3=self_image_ensemble(denoised_img3,sele_ensemble_i,inverse_flag=True)

                final_denoise_img1=final_denoise_img1+np.double(denoised_img1)
                # final_denoise_img2=final_denoise_img2+np.double(denoised_img2)
                # final_denoise_img3=final_denoise_img3+np.double(denoised_img3)


            final_denoise_img1=final_denoise_img1/self_ensemble_num
            # final_denoise_img2=final_denoise_img2/self_ensemble_num
            # final_denoise_img3=final_denoise_img3/self_ensemble_num

            crops_denoised1.append(np.uint8(final_denoise_img1))
            # crops_denoised2.append(np.uint8(final_denoise_img2))
            # crops_denoised3.append(np.uint8(final_denoise_img3))

        result_image1 = merge_image(crops_denoised1, select_row_id, select_col_id, padding_size)
        # result_image2 = merge_image(crops_denoised2, select_row_id, select_col_id, padding_size)
        # result_image3 = merge_image(crops_denoised3, select_row_id, select_col_id, padding_size)


        utils.save_img(args.result_dir + filename[0], np.uint8(result_image1))
        # utils.save_img(args.result_dir + filename[0].replace('.png','_1.png'), np.uint8(result_image2))
        # utils.save_img(args.result_dir + filename[0].replace('.png','_2.png'), np.uint8(result_image3))



if __name__ == '__main__':
    pass