from tensorflow.keras.models import Sequential
import tensorflow as tf
from tensorflow.keras.layers import Dense
import tensorflow.keras.layers as layers
import tensorflow.keras.models as models
import tensorflow_model_optimization as tfmot
import tensorflow.keras as keras
from tensorflow.keras import Input, Model
from tensorflow.keras.layers import Reshape,Conv2D,PReLU, ReLU, Concatenate,Multiply, Add,AveragePooling2D, GlobalAveragePooling2D, UpSampling2D, Softmax, MaxPooling2D
from tensorflow.keras.activations import sigmoid

class MPRNet(Model):
    def __init__(self, in_c=3, out_c=3, n_feat=80, scale_unetfeats=48, scale_orsnetfeats=32, num_cab=8, kernel_size=3,
                 reduction=4, bias=False):
        super(MPRNet, self).__init__()
        self.in_c = in_c
        self.out_c = out_c
        self.n_feat = n_feat
        self.scale_unetfeats = scale_unetfeats
        self.scale_orsnetfeats = scale_orsnetfeats
        self.num_cab = num_cab
        self.kernel_size = kernel_size
        self.reduction = reduction
        self.bias = bias

    def CA(self, X, channel, reduction=16, bias=False, name=""):

        y = GlobalAveragePooling2D()(X)
        # print("====================",y.shape)
        y = tf.reshape(y, (-1, 1, 1, channel))

        y = Conv2D(channel // reduction, kernel_size=(1, 1), padding="same", strides=(1, 1), use_bias=bias,
                   name=name + ".conv_du.0")(y)
        y = PReLU()(y)
        y = Conv2D(channel, kernel_size=(1, 1), padding="same", strides=(1, 1), use_bias=bias,
                   name=name + ".conv_du.2")(y)
        y = sigmoid(y)
        # print(X.shape,y.shape)
        return X * y

    def CAB(self, X, n_feat, kernel_size, reduction, bias, name=""):

        res = Conv2D(n_feat, kernel_size=(kernel_size, kernel_size), padding="same", strides=(1, 1), use_bias=bias,
                     name=name + ".body.0")(X)
        res = PReLU()(res)
        res = Conv2D(n_feat, kernel_size=(kernel_size, kernel_size), padding="same", strides=(1, 1), use_bias=bias,
                     name=name + ".body.1")(res)

        X += self.CA(res, n_feat, reduction, False, name + ".CA")
        return X

    def shallow_feat(self, X, n_feat, kernel_size, reduction, bias, name=""):
        X = Conv2D(n_feat, kernel_size=(kernel_size, kernel_size), padding="same", strides=(1, 1), use_bias=bias,
                   name=name + '.0')(X)

        X = self.CAB(X, n_feat, kernel_size, reduction, bias, name=name + ".1")
        return X

    def csff_coder(self, X, n_feat, kernel_size, bias, name=""):
        X = Conv2D(n_feat, kernel_size=(kernel_size, kernel_size), padding="same", strides=(1, 1), use_bias=bias,
                   name=name)(X)
        return X

    def Downsample(self, X, output_channel):
        X = AveragePooling2D(pool_size=(2, 2), strides=2, padding="valid")(X)
        X = Conv2D(output_channel, kernel_size=(1, 1), padding="same", strides=(1, 1), use_bias=False)(X)
        return X

    def Upsample(self, X, output_channel):
        X = UpSampling2D(size=(2, 2), interpolation="bilinear")(X)
        X = Conv2D(output_channel, kernel_size=(1, 1), padding="same", strides=(1, 1), use_bias=False)(X)
        return X

    def SkipUpSample(self, X, Y, output_channel, name=""):
        # X=tf.keras.layers.experimental.preprocessing.Resizing(2*X.shape[1], 2*X.shape[2], interpolation="bilinear",antialias=)(X)
        # X = tf.nn.depth_to_space(X, block_size=2, data_format='NHWC', name=None)  # pixelshuffle
        X = tf.keras.layers.Conv2DTranspose(
            filters=output_channel, kernel_size=2, strides=(2, 2), padding='valid')(X)  # Conv2DTranspose
        # X=UpSampling2D(size=(2,2),interpolation="bilinear",antialias=True)(X)#bilinear
        # X=tf.image.resize(X, size=[2*X.shape[1], 2*X.shape[2]],method="bilinear",antialias=True)

        X = Conv2D(output_channel, kernel_size=(1, 1), padding="same", strides=(1, 1), use_bias=False,
                   name=name + '.1')(X)

        return Add()([X, Y])

    def Encoder(self, X, n_feat, kernel_size, reduction, bias, scale_unetfeats, csff, encoder_outs=None,
                decoder_outs=None, name=""):  # bottom Unet
        enc1 = self.CAB(X, n_feat, kernel_size, reduction, bias, name=name + ".encoder_level1.0")
        enc1 = self.CAB(enc1, n_feat, kernel_size, reduction, bias, name=name + ".encoder_level1.1")
        if (encoder_outs is not None) and (decoder_outs is not None):
            enc1 = enc1 + self.csff_coder(encoder_outs[0], n_feat, 1, bias, name=name + ".csff_enc1") + self.csff_coder(
                decoder_outs[0], n_feat, 1, bias, name=name + ".csff_dec1")
        X = self.Downsample(enc1, n_feat + scale_unetfeats)

        enc2 = self.CAB(X, n_feat + scale_unetfeats, kernel_size, reduction, bias, name=name + ".encoder_level2.0")
        enc2 = self.CAB(enc2, n_feat + scale_unetfeats, kernel_size, reduction, bias, name=name + ".encoder_level2.1")
        if (encoder_outs is not None) and (decoder_outs is not None):
            enc2 = enc2 + self.csff_coder(encoder_outs[1], n_feat + scale_unetfeats, 1, bias,
                                          name=name + ".csff_enc2") + self.csff_coder(decoder_outs[1],
                                                                                      n_feat + scale_unetfeats, 1, bias,
                                                                                      name=name + ".csff_dec2")
        X = self.Downsample(enc2, n_feat + 2 * scale_unetfeats)

        enc3 = self.CAB(X, n_feat + 2 * scale_unetfeats, kernel_size, reduction, bias, name=name + ".encoder_level3.0")
        enc3 = self.CAB(enc3, n_feat + 2 * scale_unetfeats, kernel_size, reduction, bias,
                        name=name + ".encoder_level3.1")
        if (encoder_outs is not None) and (decoder_outs is not None):
            enc3 = enc3 + self.csff_coder(encoder_outs[2], n_feat + 2 * scale_unetfeats, 1, bias,
                                          name=name + ".csff_enc3") + self.csff_coder(decoder_outs[2],
                                                                                      n_feat + 2 * scale_unetfeats, 1,
                                                                                      bias, name=name + ".csff_dec3")

        return [enc1, enc2, enc3]

    def Decoder(self, outs, n_feat, kernel_size, reduction, bias, scale_unetfeats, name=""):
        enc1, enc2, enc3 = outs
        dec3 = self.CAB(enc3, n_feat + 2 * scale_unetfeats, kernel_size, reduction, bias,
                        name=name + '.decoder_level3.0')
        dec3 = self.CAB(dec3, n_feat + 2 * scale_unetfeats, kernel_size, reduction, bias,
                        name=name + '.decoder_level3.1')

        x = self.SkipUpSample(dec3, self.CAB(enc2, n_feat + scale_unetfeats, kernel_size, reduction, bias,
                                             name=name + ".skip_attn2"), n_feat + scale_unetfeats, name=name + ".up32")
        dec2 = self.CAB(x, n_feat + scale_unetfeats, kernel_size, reduction, bias, name=name + '.decoder_level2.0')
        dec2 = self.CAB(dec2, n_feat + scale_unetfeats, kernel_size, reduction, bias, name=name + '.decoder_level2.1')

        x = self.SkipUpSample(dec2, self.CAB(enc1, n_feat, kernel_size, reduction, bias, name=name + ".skip_attn1"),
                              n_feat, name=name + ".up21")
        dec1 = self.CAB(x, n_feat, kernel_size, reduction, bias, name=name + '.decoder_level1.0')
        dec1 = self.CAB(dec1, n_feat, kernel_size, reduction, bias, name=name + '.decoder_level1.1')
        return [dec1, dec2, dec3]

    def SAM(self, X, img, n_feat, kernel_size=1, bias=False, name=""):
        x1 = Conv2D(n_feat, kernel_size=(kernel_size, kernel_size), padding="same", strides=(1, 1), use_bias=bias,
                    name=name + ".conv1")(X)
        img = img + Conv2D(3, kernel_size=(kernel_size, kernel_size), padding="same", strides=(1, 1), use_bias=bias,
                           name=name + ".conv2")(X)
        x2 = Conv2D(n_feat, kernel_size=(kernel_size, kernel_size), padding="same", strides=(1, 1), use_bias=bias,
                    name=name + ".conv3")(img)
        x2 = sigmoid(x2)
        x1 = Multiply()([x1, x2])
        x1 = Add()([x1, X])
        return x1, img

    def ORB(self, X, n_feat, kernel_size, reduction, bias, num_cab, name=""):
        res = X
        for i in range(num_cab):
            res = self.CAB(res, n_feat, kernel_size, reduction, bias, name=name + ".body." + str(i))
        res = Conv2D(n_feat, kernel_size=(kernel_size, kernel_size), padding="same", strides=(1, 1), use_bias=bias,
                     name=name + ".body.8")(res)
        return res + X

    def ORSNet(self, X, encoder_outs, decoder_outs, n_feat, scale_orsnetfeats, kernel_size, reduction, bias,
               scale_unetfeats, num_cab, name=""):
        X = self.ORB(X, n_feat + scale_orsnetfeats, kernel_size, reduction, bias, num_cab, name=name + ".orb1")
        X = X + Conv2D(n_feat + scale_orsnetfeats, kernel_size=(1, 1), padding="same", strides=(1, 1), use_bias=bias,
                       name=name + ".conv_enc1")(encoder_outs[0]) + \
            Conv2D(n_feat + scale_orsnetfeats, kernel_size=(1, 1), padding="same", strides=(1, 1), use_bias=bias,
                   name=name + ".conv_dec1")(decoder_outs[0])

        X = self.ORB(X, n_feat + scale_orsnetfeats, kernel_size, reduction, bias, num_cab, name=name + ".orb2")
        X_temp1 = self.Upsample(encoder_outs[1], n_feat)
        X_temp2 = self.Upsample(decoder_outs[1], n_feat)
        X = X + Conv2D(n_feat + scale_orsnetfeats, kernel_size=(1, 1), padding="same", strides=(1, 1), use_bias=bias,
                       name=name + ".conv_enc2")(X_temp1) + \
            Conv2D(n_feat + scale_orsnetfeats, kernel_size=(1, 1), padding="same", strides=(1, 1), use_bias=bias,
                   name=name + ".conv_dec2")(X_temp2)

        X = self.ORB(X, n_feat + scale_orsnetfeats, kernel_size, reduction, bias, num_cab, name=name + ".orb3")
        X_temp1 = self.Upsample(encoder_outs[2], n_feat + scale_unetfeats)
        X_temp1 = self.Upsample(X_temp1, n_feat)
        X_temp2 = self.Upsample(decoder_outs[2], n_feat + scale_unetfeats)
        X_temp2 = self.Upsample(X_temp2, n_feat)
        X = X + Conv2D(n_feat + scale_orsnetfeats, kernel_size=(1, 1), padding="same", strides=(1, 1), use_bias=bias,
                       name=name + ".conv_enc3")(X_temp1) + \
            Conv2D(n_feat + scale_orsnetfeats, kernel_size=(1, 1), padding="same", strides=(1, 1), use_bias=bias,
                   name=name + ".conv_dec3")(X_temp2)

        return X

    def main_model(self, image_size):
        image = keras.Input(shape=image_size)
        ##stage1

        X1 = self.shallow_feat(image, self.n_feat, self.kernel_size, self.reduction, self.bias, name="shallow_feat1")
        feat1 = self.Encoder(X1, self.n_feat, self.kernel_size, self.reduction, self.bias, self.scale_unetfeats,
                             csff=False, name="stage1_encoder")
        res1 = self.Decoder(feat1, self.n_feat, self.kernel_size, self.reduction, self.bias, self.scale_unetfeats,
                            name="stage1_decoder")
        X2_samfeats, stage1_img = self.SAM(res1[0], image, self.n_feat, 1, self.bias, name="sam12")
        ##stage2
        X2 = self.shallow_feat(image, self.n_feat, self.kernel_size, self.reduction, self.bias, name="shallow_feat2")
        X2 = Concatenate(axis=-1)([X2, X2_samfeats])
        X2 = Conv2D(self.n_feat, self.kernel_size, padding="same", strides=(1, 1), use_bias=self.bias, name="concat12")(
            X2)

        feat2 = self.Encoder(X2, self.n_feat, self.kernel_size, self.reduction, self.bias, self.scale_unetfeats, True,
                             feat1, res1, name="stage2_encoder")
        res2 = self.Decoder(feat2, self.n_feat, self.kernel_size, self.reduction, self.bias, self.scale_unetfeats,
                            name="stage2_decoder")
        X3_samfeats, stage2_img = self.SAM(res2[0], image, self.n_feat, 1, self.bias, name="sam23")
        ##stage3
        X3 = self.shallow_feat(image, self.n_feat, self.kernel_size, self.reduction, self.bias, name="shallow_feat3")
        X3 = Concatenate(axis=-1)([X3, X3_samfeats])
        X3 = Conv2D(self.n_feat + self.scale_orsnetfeats, self.kernel_size, padding="same", strides=(1, 1),
                    use_bias=self.bias, name="concat23")(X3)
        X3 = self.ORSNet(X3, feat2, res2, self.n_feat, self.scale_orsnetfeats, self.kernel_size, self.reduction,
                         self.bias, self.scale_unetfeats, self.num_cab, name="stage3_orsnet")
        stage3_img = Conv2D(3, self.kernel_size, padding="same", strides=(1, 1), use_bias=self.bias, name="tail")(
            X3) + image
        # return [stage3_img,stage2_img,stage1_img]
        # model = Model(inputs=[image], outputs=[stage3_img,stage2_img,stage1_img])
        model = Model(inputs=[image], outputs=[stage1_img])
        model.compile(optimizer=tf.keras.optimizers.Adam(lr=1e-4), loss='mse', metrics=['mse'])
        return model
        #


# TF-LITE MPRNet
def convert_model(model):
    # Defining the model
    # model = MyNet((720, 1280, 3))
    # print(model.)
    # model=tfmot.quantization.keras.quantize_model(model)
    # Load your pre-trained model
    # model.load_weights("path/to/your/saved/model")

    # Export your model to the TFLite format
    converter = tf.lite.TFLiteConverter.from_keras_model(model)

    # Be very careful here:
    # "experimental_new_converter" is enabled by default in TensorFlow 2.2+. However, using the new MLIR TFLite
    # converter might result in corrupted / incorrect TFLite models for some particular architectures. Therefore, the
    # best option is to perform the conversion using both the new and old converter and check the results in each case:
    # converter.experimental_new_converter = False
    # converter._experimental_new_quantizer = False

    converter.experimental_new_converter = False
    # converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS,tf.lite.OpsSet.SELECT_TF_OPS]

    ##False False ok
    # converter.optimizations = [tf.lite.Optimize.DEFAULT]
    # converter.optimizations = [tf.lite.Optimize.OPTIMIZE_FOR_LATENCY]

    # converter.representative_dataset = representative_dataset

    # converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
    # converter.inference_input_type = tf.uint8
    # converter.inference_output_type = tf.uint8

    tflite_model = converter.convert()
    open("MPR_model_Relu.tflite", "wb").write(tflite_model)

    # -----------------------------------------------------------------------------
    # That's it! Your model is now saved as model.tflite file
    # You can now try to run it using the PRO mode of the AI Benchmark application:
    # https://play.google.com/store/apps/details?id=org.benchmark.demo
    # More details can be found here (RUNTIME VALIDATION):
    # https://ai-benchmark.com/workshops/mai/2021/#runtime
    # -----------------------------------------------------------------------------





#save model
My_Net=MPRNet().main_model


model=My_Net((64, 64, 3))
# print(model.layers)
model.save_weights("MPR_model-keras_Relu.h5")

convert_model(model)
# exit(0)







#load tf lite and keras model,check the output
import numpy as np
import random
def setup_seed(seed):
  np.random.seed(seed)
  random.seed(seed)
setup_seed(1)
rand_input=np.random.randn(1,64,64,3).astype(np.float32)
# print(rand_input)

#keras output
My_Net=MPRNet().main_model
model=My_Net((64, 64, 3))
model.load_weights('MPR_model-keras_Relu.h5')
output=model(rand_input)
print(output)

# #tflite output
from tensorflow.lite.python import interpreter as interpreter_wrapper
tflite_file = "MPR_model_Relu.tflite"
interpreter = interpreter_wrapper.Interpreter(model_path=tflite_file)
interpreter.allocate_tensors()
# print(input_details[0]['dtype'])
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()
height = input_details[0]['shape'][1]#64
width = input_details[0]['shape'][2]#64
interpreter.set_tensor(input_details[0]['index'], rand_input)
interpreter.invoke()
output_data = interpreter.get_tensor(output_details[0]['index'])
# results = np.resize(output_data, [height, width, 3])
print(output_data)
