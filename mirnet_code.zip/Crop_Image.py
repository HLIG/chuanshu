import cv2
import numpy as np
from typing import Tuple,List
import scipy.io as sio
def crop_image(image:np.ndarray,crop_row:int,crop_col:int,padding_size:int)->(int,int,List[np.ndarray]):
    crop_results=[]
    select_row_id=[]
    select_col_id = []
    rows,cols=image.shape[0],image.shape[1]
    select_row_id=list(range(0,rows,crop_row))
    select_col_id = list(range(0, cols, crop_col))
    select_row_id[-1]=rows-crop_row
    select_col_id[-1] = cols - crop_col
    for row_id in select_row_id:
        for col_id in select_col_id:
            left_top_row_src=max(row_id-padding_size,0)
            left_top_col_src = max(col_id - padding_size, 0)
            right_bottom_row_src=min(row_id+crop_row+padding_size,rows)
            right_bottom_col_src = min(col_id + crop_col + padding_size, cols)
            left_top_row_crop=0 if row_id>=padding_size else padding_size-row_id
            left_top_col_crop = 0 if col_id >= padding_size else padding_size - col_id
            right_bottom_row_crop = left_top_row_crop+right_bottom_row_src-left_top_row_src
            right_bottom_col_crop = left_top_col_crop+right_bottom_col_src-left_top_col_src
            crop_img=0.
            if len(image.shape)==3:
                crop_img=np.zeros((crop_row+2*padding_size,crop_col+2*padding_size,3))
                crop_img[left_top_row_crop:right_bottom_row_crop,left_top_col_crop:right_bottom_col_crop,:]=image[left_top_row_src:right_bottom_row_src,left_top_col_src:right_bottom_col_src,:]
            elif len(image.shape)==2:
                crop_img = np.zeros((crop_row + 2 * padding_size, crop_col + 2 * padding_size))
                crop_img[left_top_row_crop:right_bottom_row_crop, left_top_col_crop:right_bottom_col_crop] = image[left_top_row_src:right_bottom_row_src,left_top_col_src:right_bottom_col_src]
            else:
                print("The input image should be gray or rgb")
                exit(-1)
            crop_results.append(np.float32(crop_img))
    return select_row_id,select_col_id,crop_results

def merge_image(crop_images:List[np.ndarray],select_row_id: List[int],select_col_id: List[int],padding_size:int)->np.ndarray:
    result_image=0
    crop_rows,crop_cols=crop_images[0].shape[0]-2*padding_size,crop_images[0].shape[1]-2*padding_size
    result_rows,result_cols=[select_row_id[-1]+crop_rows,select_col_id[-1]+crop_cols]
    if len(crop_images[0].shape) == 3:
        result_image=np.zeros((result_rows,result_cols,3))
        weight_image = np.zeros((result_rows, result_cols, 3))
        for row_i,row_id in enumerate(select_row_id):
            for col_i, col_id in enumerate(select_col_id):
                crop_index=len(select_col_id)*row_i+col_i
                result_image[row_id:(row_id+crop_rows),col_id:(col_id+crop_cols),:]+=crop_images[crop_index][padding_size:(padding_size+crop_rows),padding_size:(padding_size+crop_cols),:]
                weight_image[row_id:(row_id+crop_rows),col_id:(col_id+crop_cols),:]+=1
    elif len(crop_images[0].shape) == 2:
        result_image = np.zeros((result_rows, result_cols))
        weight_image = np.zeros((result_rows, result_cols))
        for row_i, row_id in enumerate(select_row_id):
            for col_i, col_id in enumerate(select_col_id):
                crop_index = len(select_col_id) * row_i + col_i
                result_image[row_id:(row_id + crop_rows), col_id:(col_id + crop_cols)] += crop_images[crop_index][padding_size:(padding_size + crop_rows),padding_size:(padding_size + crop_cols)]
                weight_image[row_id:(row_id + crop_rows), col_id:(col_id + crop_cols)] += 1
    else:
        print("The input image should be gray or rgb")
        exit(-1)
    result_image=result_image/weight_image
    return result_image

if __name__=='__main__':
    image=cv2.imread("167.png",cv2.IMREAD_UNCHANGED)
    crop_row=320
    crop_col = 320
    padding_size=32
    select_row_id, select_col_id, crop_results=crop_image(image,crop_row,crop_col,padding_size)
    result_image=merge_image(crop_results,select_row_id,select_col_id,padding_size)

    img = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)






