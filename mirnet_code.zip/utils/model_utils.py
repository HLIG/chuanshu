import torch
import os
from collections import OrderedDict

def freeze(model):
    for p in model.parameters():
        p.requires_grad=False

def unfreeze(model):
    for p in model.parameters():
        p.requires_grad=True

def is_frozen(model):
    x = [p.requires_grad for p in model.parameters()]
    return not all(x)

def save_checkpoint(model_dir, state, session):
    epoch = state['epoch']
    model_out_path = os.path.join(model_dir,"model_epoch_{}_{}.pth".format(epoch,session))
    torch.save(state, model_out_path)

def load_checkpoint(model, weights):
    checkpoint = torch.load(weights)
    try:
        new_state_dict=checkpoint["state_dict"]
        dict_to_load={}
        for k, v in model.state_dict().items():
            # print(model.state_dict()[k].shape,v.shape)
            # exit(0)
            if k in new_state_dict and (new_state_dict[k].shape == v.shape):
                dict_to_load[k] = new_state_dict[k]#{k: v for k, v in new_state_dict.items() }
                # print("load weight:", k)
            else:
                dict_to_load[k]=v
                print("unload weight:",k)
        # print(new_state_dict.keys())
        model.load_state_dict(dict_to_load)
    except:
        state_dict = checkpoint["state_dict"]
        new_state_dict = OrderedDict()
        for k, v in state_dict.items():
            name = k[7:] # remove `module.`
            new_state_dict[name] = v
        print(new_state_dict.keys())

        # 2. overwrite entries in the existing state dict


        model.load_state_dict(new_state_dict)


def load_checkpoint_multigpu(model, weights):
    checkpoint = torch.load(weights)
    state_dict = checkpoint["state_dict"]
    new_state_dict = OrderedDict()
    for k, v in state_dict.items():
        name = k[7:] # remove `module.`
        new_state_dict[name] = v
    model.load_state_dict(new_state_dict)

def load_start_epoch(weights):
    checkpoint = torch.load(weights)
    epoch=0
    if "epoch" in checkpoint.keys():
        epoch = checkpoint["epoch"]
    return epoch

def load_optim(optimizer, weights):
    checkpoint = torch.load(weights)
    lr=None
    if "optimizer" in checkpoint.keys():
        optimizer.load_state_dict(checkpoint['optimizer'])
        for p in optimizer.param_groups: lr = p['lr']
    return lr
