# Copyright 2021 by Andrey Ignatov. All Rights Reserved.

# The following instructions will show you how to test your converted (quantized / floating-point) TFLite model
# on the real images

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

from PIL import Image
import numpy as np
import os

from tensorflow.lite.python import interpreter as interpreter_wrapper

import random
import numpy as np


def setup_seed(seed):
    np.random.seed(seed)
    random.seed(seed)



if __name__ == "__main__":

    # Specify the name of your TFLite model and the location of the sample test images
    setup_seed(1)
    input_data=np.random.randn(1,64,64,3).astype(np.float32)

    model_file = "E:\goodix\HLG\competition\Denoise\MPR_model_test.tflite"

    # Load your TFLite model

    interpreter = interpreter_wrapper.Interpreter(model_path=model_file)
    interpreter.allocate_tensors()

    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    floating_model = True

    if input_details[0]['dtype'] == type(np.float32(1.0)):
        floating_model = True

    # Get the size of the input / output tensors

    height = input_details[0]['shape'][1]
    width = input_details[0]['shape'][2]

    # Process test images and display the results









    interpreter.set_tensor(input_details[0]['index'], input_data)
    interpreter.invoke()

    output_data = interpreter.get_tensor(output_details[0]['index'])
    print(output_data)
        # results = np.squeeze(output_data)
        #
        # prediction = np.argmax(results)
        # prediction_top_3 = results.argsort()[-3:][::-1]
        #
        # print("Image " + image_name + ", predicted classes: \t %d, %d, %d" %
        #       (prediction_top_3[0], prediction_top_3[1], prediction_top_3[2]))

