import cv2
def self_image_ensemble(image,aug_i,inverse_flag=False):
    result=0.
    if not inverse_flag:
        rgb_noisy=image
        if aug_i%4==0 and aug_i<4:
            pass
        elif aug_i % 4 == 0 and aug_i >= 4:
            rgb_noisy=cv2.flip(rgb_noisy,0)
        elif aug_i % 4 == 1 and aug_i < 4:
            rgb_noisy = cv2.rotate(rgb_noisy, cv2.ROTATE_90_CLOCKWISE)
        elif aug_i % 4 == 1 and aug_i >= 4:
            rgb_noisy = cv2.rotate(rgb_noisy, cv2.ROTATE_90_CLOCKWISE)
            rgb_noisy = cv2.flip(rgb_noisy, 0)
        elif aug_i % 4 == 2 and aug_i < 4:
            rgb_noisy = cv2.rotate(rgb_noisy, cv2.ROTATE_180)
        elif aug_i % 4 == 2 and aug_i >= 4:
            rgb_noisy = cv2.rotate(rgb_noisy, cv2.ROTATE_180)
            rgb_noisy = cv2.flip(rgb_noisy, 0)
        elif aug_i % 4 == 3 and aug_i < 4:
            rgb_noisy = cv2.rotate(rgb_noisy, cv2.ROTATE_90_COUNTERCLOCKWISE)
        elif aug_i % 4 == 3 and aug_i >= 4:
            rgb_noisy = cv2.rotate(rgb_noisy, cv2.ROTATE_90_COUNTERCLOCKWISE)
            rgb_noisy = cv2.flip(rgb_noisy, 0)
        result= rgb_noisy
    else:
        denoised_img=image
        if aug_i % 4 == 0 and aug_i < 4:
            pass
        elif aug_i % 4 == 0 and aug_i >= 4:
            denoised_img = cv2.flip(denoised_img, 0)
        elif aug_i % 4 == 1 and aug_i < 4:
            denoised_img = cv2.rotate(denoised_img, cv2.ROTATE_90_COUNTERCLOCKWISE)
        elif aug_i % 4 == 1 and aug_i >= 4:
            denoised_img = cv2.flip(denoised_img, 0)
            denoised_img = cv2.rotate(denoised_img, cv2.ROTATE_90_COUNTERCLOCKWISE)
        elif aug_i % 4 == 2 and aug_i < 4:
            denoised_img = cv2.rotate(denoised_img, cv2.ROTATE_180)
        elif aug_i % 4 == 2 and aug_i >= 4:
            denoised_img = cv2.flip(denoised_img, 0)
            denoised_img = cv2.rotate(denoised_img, cv2.ROTATE_180)
        elif aug_i % 4 == 3 and aug_i < 4:
            denoised_img = cv2.rotate(denoised_img, cv2.ROTATE_90_CLOCKWISE)
        elif aug_i % 4 == 3 and aug_i >= 4:
            denoised_img = cv2.flip(denoised_img, 0)
            denoised_img = cv2.rotate(denoised_img, cv2.ROTATE_90_CLOCKWISE)
        result=denoised_img
    return result
if __name__=='__main__':
    image = cv2.imread("167.png", cv2.IMREAD_UNCHANGED)
    for aug_i in range(8):
        print(aug_i)
        image_input=self_image_ensemble(image,aug_i,inverse_flag=False)
        image_output = self_image_ensemble(image_input, aug_i, inverse_flag=True)
        cv2.namedWindow("image_output",0)
        cv2.imshow("image_output",image_output)
        cv2.waitKey(0)





